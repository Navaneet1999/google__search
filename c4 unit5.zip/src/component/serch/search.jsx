import { Body } from "./body/body"
import { Navbar } from "./navbar/navbar"

export const Search = () => {
    return(
        <div>
            <Navbar/>
            <hr></hr>
            <Body/>
        </div>
    )
}