import { ADD_SEARCH } from "./actionsType";

export const addSearch = {
    type: ADD_SEARCH,
    payload,
} 